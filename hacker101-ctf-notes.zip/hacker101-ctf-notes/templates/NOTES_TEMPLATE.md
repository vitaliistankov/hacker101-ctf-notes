# Challenge Title

## Summary
**Source:** Hacker101 CTF  
**Category:** Web / (XSS, IDOR, LFI, etc.)  
**Points:** ?

---

## Recon
| Step | Action | Result | Tool |
|---|---|---|---|
| 1 | Load initial page |  | Browser |
| 2 | View source |  | Browser (Ctrl+U) |

---

## Vulnerability theme
*Short explanation of the core weakness.*

---

## Steps to reproduce / Exploit path
1. Step 1 — what you did
2. Step 2 — commands, payloads, endpoints
3. Step 3 — how you verified success

---

## Final payloads / commands
```bash
# example curl or fetch commands
curl -i "https://target/endpoint"
```

---

## Flag
<PASTE FLAG HERE OR LEAVE BLANK>

---

## Artifacts
- screenshots/
- downloads/
- scripts/

---

## Lessons learned
- Concise takeaways and what to check next time.
