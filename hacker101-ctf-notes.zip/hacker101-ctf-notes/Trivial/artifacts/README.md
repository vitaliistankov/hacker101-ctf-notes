Place screenshots, downloads, and other artifacts related to this challenge here.
